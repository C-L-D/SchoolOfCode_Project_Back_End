
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'claireld',
  applicationName: 'royal-code',
  appUid: 'Mcplx7LrLRg6Fkf5C1',
  orgUid: 'da3c8eec-653e-4acb-a887-f0e86be8dabe',
  deploymentUid: '299e0e7f-7610-4fd0-81b8-b7e792c28720',
  serviceName: 'royal-code',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.5.1',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'royal-code-dev-updateBootcamperPairs', timeout: 6 };

try {
  const userHandler = require('./handlerBootcamperPairs.js');
  module.exports.handler = serverlessSDK.handler(userHandler.updateBootcamperPair, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}